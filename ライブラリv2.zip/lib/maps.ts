export function buildGoogleMapsDirectionsUrl(
  stops: Array<string | null | undefined>
): string | null {
  const normalizedStops = stops
    .map((stop) => (stop ?? '').trim())
    .filter((stop) => stop.length > 0)

  if (normalizedStops.length < 2) {
    return null
  }

  const encodedStops = normalizedStops.map((stop) => encodeURIComponent(stop))
  return `https://www.google.com/maps/dir/${encodedStops.join('/')}`
}